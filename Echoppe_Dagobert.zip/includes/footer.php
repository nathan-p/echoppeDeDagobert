<footer>
		
		<div class="row">
			<div class="col-md-3">
				<h1> 
					<p><b>Echoppe</b></p>	 
					<p><b>Dagobert</b></p>
				</h1>
				<small>© 2015 ECOMMERCE SOFTWARE BY IPIC Industries™</small>
			</div>
			<div class="col-md-3">
				<h3 class="footer-categories">INFORMATIONS</h3>
				<ul class="list-unstyled">
					<li><a href="./FAQ.php">Foire aux questions</a></li>
					<li><a href="./conditionVente.php">Conditions générales de vente</a></li>
					<li><a href="./contact.php">Contact</a></li>
				</ul>


			</div>
			<div class="col-md-3">
				<h3 class="footer-categories">MON COMPTE</h3>
				<ul class="list-unstyled">
					<li><a href="./compte.php">Mon compte</a></li>
					<li><a href="./panier.php">Mon panier</a></li>
					<li><a href="./compte.php">Mes commandes</a></li>
					<li><a href="./compte.php">Modifier mon adresse</a></li>
				</ul>
			</div>
			<div class="col-md-3">
				<h3 class="footer-categories">NOUS SUIVRE</h3>
				<ul class="list-unstyled">
					<li><a href="https://www.facebook.com/">Facebook</a></li>
					<li><a href="https://www.twitter.com/">Twitter</a></li>
				</ul>
				
			</div>

		</div>
	</footer>

</body>
</html>